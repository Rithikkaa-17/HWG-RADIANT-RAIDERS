import React from 'react';
import { Brain } from 'lucide-react';

const HomePage: React.FC = () => {
  // Content for modals/pages
  const resources = {
    documentation: {
      title: "Documentation",
      content: `Our comprehensive documentation covers everything you need to know about the Smart Implant Nano Heal System:
      • Detailed system overview and features
      • Step-by-step usage guides
      • Technical specifications
      • Troubleshooting guides
      • Best practices and recommendations
      • System updates and maintenance`
    },
    medicalReferences: {
      title: "Medical References",
      content: `Access peer-reviewed research and clinical studies:
      • Clinical trials and outcomes
      • Case studies and success stories
      • Medical journals and publications
      • Industry standards and guidelines
      • Latest research in implant technology
      • Expert opinions and analyses`
    },
    research: {
      title: "Research",
      content: `Stay updated with the latest advancements:
      • Ongoing clinical trials
      • New technological developments
      • Innovation in implant materials
      • AI and machine learning applications
      • Future of implant monitoring
      • Collaborative research projects`
    },
    privacy: {
      title: "Privacy Policy",
      content: `We take your privacy seriously:
      • Data collection and usage
      • Security measures
      • Patient confidentiality
      • HIPAA compliance
      • Data storage and retention
      • Your rights and controls`
    },
    terms: {
      title: "Terms of Service",
      content: `Our terms ensure clear understanding:
      • Service agreements
      • User responsibilities
      • Liability limitations
      • Usage restrictions
      • Warranty information
      • Dispute resolution`
    }
  };

  return (
    <div className="bg-white">
      {/* Hero Section */}
      <div className="relative bg-gradient-to-r from-teal-500 to-teal-700 overflow-hidden">
        <div className="max-w-7xl mx-auto">
          <div className="relative z-10 pb-8 bg-gradient-to-r from-teal-500 to-teal-700 sm:pb-16 md:pb-20 lg:max-w-2xl lg:w-full lg:pb-28 xl:pb-32">
            <svg
              className="hidden lg:block absolute right-0 inset-y-0 h-full w-48 text-teal-700 transform translate-x-1/2"
              fill="currentColor"
              viewBox="0 0 100 100"
              preserveAspectRatio="none"
              aria-hidden="true"
            >
              <polygon points="50,0 100,0 50,100 0,100" />
            </svg>

            <div className="pt-10 sm:pt-16 lg:pt-8 xl:pt-16">
              <div className="sm:text-center lg:text-left px-4 sm:px-8 xl:pr-16">
                <h1 className="text-4xl tracking-tight font-bold text-white sm:text-5xl md:text-6xl lg:text-5xl xl:text-6xl">
                  <span className="block">Smart Implant</span>
                  <span className="block text-teal-200">Nano Heal System</span>
                </h1>
                <p className="mt-3 text-base text-teal-100 sm:mt-5 sm:text-lg sm:max-w-xl sm:mx-auto md:mt-5 md:text-xl lg:mx-0">
                  Advanced AI-powered analysis for medical implants. Upload X-ray images and get instant classification and professional recommendations.
                </p>
                <div className="mt-5 sm:mt-8 sm:flex sm:justify-center lg:justify-start">
                  <div className="rounded-md shadow">
                    <a
                      href="#upload"
                      className="w-full flex items-center justify-center px-8 py-3 border border-transparent text-base font-medium rounded-md text-teal-700 bg-white hover:bg-gray-50 md:py-4 md:text-lg md:px-10"
                    >
                      Upload X-Ray
                    </a>
                  </div>
                  <div className="mt-3 sm:mt-0 sm:ml-3">
                    <a
                      href="#chat"
                      className="w-full flex items-center justify-center px-8 py-3 border border-transparent text-base font-medium rounded-md text-white bg-teal-800 hover:bg-teal-900 md:py-4 md:text-lg md:px-10"
                    >
                      Ask Questions
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="lg:absolute lg:inset-y-0 lg:right-0 lg:w-1/2">
          <img
            className="h-56 w-full object-cover sm:h-72 md:h-96 lg:w-full lg:h-full"
            src="https://images.pexels.com/photos/6749419/pexels-photo-6749419.jpeg"
            alt="Medical X-ray"
          />
        </div>
      </div>

      {/* Features Section */}
      <div className="py-12 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="lg:text-center">
            <h2 className="text-base text-teal-600 font-semibold tracking-wide uppercase">Features</h2>
            <p className="mt-2 text-3xl leading-8 font-bold tracking-tight text-gray-900 sm:text-4xl">
              A smarter way to analyze medical implants
            </p>
            <p className="mt-4 max-w-2xl text-xl text-gray-500 lg:mx-auto">
              Our AI-powered system provides comprehensive analysis and recommendations for medical implants.
            </p>
          </div>

          <div className="mt-10">
            <div className="space-y-10 md:space-y-0 md:grid md:grid-cols-2 md:gap-x-8 md:gap-y-10">
              <div className="flex">
                <div className="flex-shrink-0">
                  <div className="flex items-center justify-center h-12 w-12 rounded-md bg-teal-500 text-white">
                    <svg className="h-6 w-6" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4M7.835 4.697a3.42 3.42 0 001.946-.806 3.42 3.42 0 014.438 0 3.42 3.42 0 001.946.806 3.42 3.42 0 013.138 3.138 3.42 3.42 0 00.806 1.946 3.42 3.42 0 010 4.438 3.42 3.42 0 00-.806 1.946 3.42 3.42 0 01-3.138 3.138 3.42 3.42 0 00-1.946.806 3.42 3.42 0 01-4.438 0 3.42 3.42 0 00-1.946-.806 3.42 3.42 0 01-3.138-3.138 3.42 3.42 0 00-.806-1.946 3.42 3.42 0 010-4.438 3.42 3.42 0 00.806-1.946 3.42 3.42 0 013.138-3.138z" />
                    </svg>
                  </div>
                </div>
                <div className="ml-4">
                  <h3 className="text-lg leading-6 font-medium text-gray-900">Accurate Classification</h3>
                  <p className="mt-2 text-base text-gray-500">
                    Our AI engine precisely categorizes your implant as Accepted, Rejected, Infected, or Disinfected with high confidence.
                  </p>
                </div>
              </div>

              <div className="flex">
                <div className="flex-shrink-0">
                  <div className="flex items-center justify-center h-12 w-12 rounded-md bg-teal-500 text-white">
                    <svg className="h-6 w-6" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
                    </svg>
                  </div>
                </div>
                <div className="ml-4">
                  <h3 className="text-lg leading-6 font-medium text-gray-900">Instant Analysis</h3>
                  <p className="mt-2 text-base text-gray-500">
                    Upload your X-ray and receive results within seconds, helping you make informed decisions quickly.
                  </p>
                </div>
              </div>

              <div className="flex">
                <div className="flex-shrink-0">
                  <div className="flex items-center justify-center h-12 w-12 rounded-md bg-teal-500 text-white">
                    <svg className="h-6 w-6" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 20H5a2 2 0 01-2-2V6a2 2 0 012-2h10a2 2 0 012 2v1m2 13a2 2 0 01-2-2V7m2 13a2 2 0 002-2V9a2 2 0 00-2-2h-2m-4-3H9M7 16h6M7 8h6v4H7V8z" />
                    </svg>
                  </div>
                </div>
                <div className="ml-4">
                  <h3 className="text-lg leading-6 font-medium text-gray-900">Doctor Recommendations</h3>
                  <p className="mt-2 text-base text-gray-500">
                    Receive tailored medical recommendations based on your analysis results from our AI-powered system.
                  </p>
                </div>
              </div>

              <div className="flex">
                <div className="flex-shrink-0">
                  <div className="flex items-center justify-center h-12 w-12 rounded-md bg-teal-500 text-white">
                    <svg className="h-6 w-6" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z" />
                    </svg>
                  </div>
                </div>
                <div className="ml-4">
                  <h3 className="text-lg leading-6 font-medium text-gray-900">Intelligent Chat Support</h3>
                  <p className="mt-2 text-base text-gray-500">
                    Ask medical questions about your implant and get clear, helpful answers from our AI assistant.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* CTA Section */}
      <div className="bg-teal-700">
        <div className="max-w-2xl mx-auto text-center py-16 px-4 sm:py-20 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-extrabold text-white sm:text-4xl">
            <span className="block">Ready to analyze your implant?</span>
          </h2>
          <p className="mt-4 text-lg leading-6 text-teal-100">
            Upload your X-ray image and get instant professional analysis and recommendations.
          </p>
          <a
            href="#"
            className="mt-8 w-full inline-flex items-center justify-center px-5 py-3 border border-transparent text-base font-medium rounded-md text-teal-700 bg-white hover:bg-teal-50 sm:w-auto"
          >
            <Brain className="mr-2 h-5 w-5 text-teal-600" />
            Get Started
          </a>
        </div>
      </div>

      {/* Resources Section */}
      <div className="bg-gray-50 py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="lg:text-center mb-12">
            <h2 className="text-base text-teal-600 font-semibold tracking-wide uppercase">Resources</h2>
            <p className="mt-2 text-3xl leading-8 font-bold tracking-tight text-gray-900 sm:text-4xl">
              Everything you need to know
            </p>
          </div>

          <div className="grid grid-cols-1 gap-8 md:grid-cols-2 lg:grid-cols-3">
            {/* Documentation */}
            <div className="bg-white rounded-lg shadow-sm p-6 hover:shadow-md transition-shadow">
              <h3 className="text-lg font-semibold text-gray-900 mb-2">{resources.documentation.title}</h3>
              <p className="text-gray-600 mb-4">{resources.documentation.content}</p>
              <a href="/documentation" className="text-teal-600 hover:text-teal-700 font-medium">
                Learn more →
              </a>
            </div>

            {/* Medical References */}
            <div className="bg-white rounded-lg shadow-sm p-6 hover:shadow-md transition-shadow">
              <h3 className="text-lg font-semibold text-gray-900 mb-2">{resources.medicalReferences.title}</h3>
              <p className="text-gray-600 mb-4">{resources.medicalReferences.content}</p>
              <a href="/medical-references" className="text-teal-600 hover:text-teal-700 font-medium">
                View references →
              </a>
            </div>

            {/* Research */}
            <div className="bg-white rounded-lg shadow-sm p-6 hover:shadow-md transition-shadow">
              <h3 className="text-lg font-semibold text-gray-900 mb-2">{resources.research.title}</h3>
              <p className="text-gray-600 mb-4">{resources.research.content}</p>
              <a href="/research" className="text-teal-600 hover:text-teal-700 font-medium">
                Explore research →
              </a>
            </div>
          </div>
        </div>
      </div>

      {/* Support Section */}
      <div className="bg-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="lg:text-center mb-12">
            <h2 className="text-base text-teal-600 font-semibold tracking-wide uppercase">Support</h2>
            <p className="mt-2 text-3xl leading-8 font-bold tracking-tight text-gray-900 sm:text-4xl">
              We're here to help
            </p>
          </div>

          <div className="grid grid-cols-1 gap-8 md:grid-cols-2">
            <div className="bg-gray-50 rounded-lg p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Contact Us</h3>
              <div className="space-y-3">
                <p className="text-gray-600">
                  <a href="mailto:rithusj17@gmail.com" className="text-teal-600 hover:text-teal-700">
                    rithusj17@gmail.com
                  </a>
                </p>
                <p className="text-gray-600">
                  <a href="mailto:rishiraman212005@gmail.com" className="text-teal-600 hover:text-teal-700">
                    rishiraman212005@gmail.com
                  </a>
                </p>
              </div>
            </div>

            <div className="bg-gray-50 rounded-lg p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Legal Information</h3>
              <div className="space-y-3">
                <p className="text-gray-600">
                  <a href="/privacy-policy" className="text-teal-600 hover:text-teal-700">
                    Privacy Policy
                  </a>
                  <br />
                  <span className="text-sm">{resources.privacy.content}</span>
                </p>
                <p className="text-gray-600">
                  <a href="/terms-of-service" className="text-teal-600 hover:text-teal-700">
                    Terms of Service
                  </a>
                  <br />
                  <span className="text-sm">{resources.terms.content}</span>
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default HomePage;