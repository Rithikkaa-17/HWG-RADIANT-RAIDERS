import React, { useState } from 'react';
import ImageUploader from '../components/ImageUploader';
import AnalysisResult from '../components/AnalysisResult';
import Chat from '../components/Chat';
import { AnalysisResult as AnalysisResultType, ImageClassification } from '../types';
import { initialMessages } from '../data/mockData';

const UploadPage: React.FC = () => {
  const [isProcessing, setIsProcessing] = useState(false);
  const [result, setResult] = useState<AnalysisResultType | null>(null);

  const handleImageUpload = async (file: File) => {
    // This would normally send the image to a backend for processing
    // Here we'll simulate the analysis with a timeout
    setIsProcessing(true);
    setResult(null);
    
    // Simulate processing delay
    setTimeout(() => {
      const classifications: ImageClassification[] = ['accepted', 'rejected', 'infected', 'disinfected'];
      const randomClassification = classifications[Math.floor(Math.random() * classifications.length)];
      
      const recommendations = {
        accepted: "The implant is correctly positioned and shows no signs of issues. Continue with your regular check-up schedule.",
        rejected: "The implant shows signs of rejection. Please consult with your physician immediately for possible removal.",
        infected: "Signs of infection detected around the implant. Antibiotic treatment recommended. Consult your doctor immediately.",
        disinfected: "Previous infection has been resolved. Continue monitoring for any recurring symptoms."
      };
      
      const newResult: AnalysisResultType = {
        id: Math.random().toString(36).substring(2, 11),
        classification: randomClassification,
        confidence: 0.85 + Math.random() * 0.1,
        recommendation: recommendations[randomClassification as keyof typeof recommendations] || "",
        date: new Date().toISOString()
      };
      
      setResult(newResult);
      setIsProcessing(false);
    }, 3000);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div className="text-center mb-12">
        <h1 className="text-3xl font-bold text-gray-900 sm:text-4xl">Upload X-Ray Image</h1>
        <p className="mt-3 max-w-2xl mx-auto text-xl text-gray-500 sm:mt-4">
          Upload your X-ray image for instant AI analysis and medical recommendations
        </p>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div id="upload" className="space-y-8">
          <div className="bg-white p-6 rounded-lg shadow-sm">
            <h2 className="text-xl font-medium text-gray-900 mb-4">Image Upload</h2>
            <ImageUploader onImageUpload={handleImageUpload} isProcessing={isProcessing} />
          </div>
          
          <AnalysisResult result={result} loading={isProcessing} />
        </div>
        
        <div id="chat" className="space-y-8">
          <div className="bg-white p-6 rounded-lg shadow-sm">
            <h2 className="text-xl font-medium text-gray-900 mb-4">Get Medical Assistance</h2>
            <p className="text-gray-600 mb-4">
              Have questions about your implant or analysis results? Chat with our AI medical assistant.
            </p>
            <Chat initialMessages={initialMessages} />
          </div>
        </div>
      </div>
      
      <div className="mt-16 border-t border-gray-200 pt-8">
        <div className="bg-gray-50 p-6 rounded-lg">
          <h3 className="text-lg font-medium text-gray-900 mb-2">Important Note</h3>
          <p className="text-gray-600">
            This analysis is provided as a preliminary assessment tool only. Always consult with a qualified healthcare professional for proper diagnosis and treatment advice. The AI recommendations are not a substitute for professional medical advice.
          </p>
        </div>
      </div>
    </div>
  );
};

export default UploadPage;