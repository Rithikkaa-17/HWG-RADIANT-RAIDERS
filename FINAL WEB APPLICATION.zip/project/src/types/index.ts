export type ImageClassification = 'accepted' | 'rejected' | 'infected' | 'disinfected' | null;

export interface AnalysisResult {
  id: string;
  classification: ImageClassification;
  confidence: number;
  recommendation: string;
  date: string;
}

export interface UploadedImage {
  id: string;
  url: string;
  name: string;
  date: string;
  result?: AnalysisResult;
}

export interface Message {
  id: string;
  content: string;
  sender: 'user' | 'system';
  timestamp: string;
}

export interface Report {
  id: string;
  title: string;
  date: string;
  doctorName: string;
  specialty: string;
  content: string;
  attachments: string[];
  status: 'normal' | 'attention' | 'critical';
}