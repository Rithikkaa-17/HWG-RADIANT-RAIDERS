import React from 'react';
import { CheckCircle, XCircle, AlertTriangle, Droplets, Loader2 } from 'lucide-react';
import { AnalysisResult as AnalysisResultType } from '../types';

interface AnalysisResultProps {
  result: AnalysisResultType | null;
  loading: boolean;
}

const AnalysisResult: React.FC<AnalysisResultProps> = ({ result, loading }) => {
  if (loading) {
    return (
      <div className="bg-white rounded-lg shadow p-6 flex flex-col items-center justify-center h-64">
        <Loader2 className="h-12 w-12 text-teal-500 animate-spin" />
        <p className="mt-4 text-gray-600">Analyzing your X-ray image...</p>
        <p className="text-sm text-gray-500 mt-2">This may take a few moments</p>
      </div>
    );
  }

  if (!result) {
    return null;
  }

  const getStatusIcon = () => {
    switch (result.classification) {
      case 'accepted':
        return <CheckCircle className="h-12 w-12 text-green-500" />;
      case 'rejected':
        return <XCircle className="h-12 w-12 text-red-500" />;
      case 'infected':
        return <AlertTriangle className="h-12 w-12 text-amber-500" />;
      case 'disinfected':
        return <Droplets className="h-12 w-12 text-blue-500" />;
      default:
        return null;
    }
  };

  const getStatusColor = () => {
    switch (result.classification) {
      case 'accepted':
        return 'bg-green-50 border-green-200 text-green-800';
      case 'rejected':
        return 'bg-red-50 border-red-200 text-red-800';
      case 'infected':
        return 'bg-amber-50 border-amber-200 text-amber-800';
      case 'disinfected':
        return 'bg-blue-50 border-blue-200 text-blue-800';
      default:
        return 'bg-gray-50 border-gray-200 text-gray-800';
    }
  };

  const getStatusText = () => {
    switch (result.classification) {
      case 'accepted':
        return 'Accepted';
      case 'rejected':
        return 'Rejected';
      case 'infected':
        return 'Infected';
      case 'disinfected':
        return 'Disinfected';
      default:
        return 'Unknown';
    }
  };

  return (
    <div className="bg-white rounded-lg shadow overflow-hidden transition-all duration-300 transform hover:shadow-md">
      <div className={`p-4 ${getStatusColor()} flex items-center justify-between`}>
        <div className="flex items-center">
          {getStatusIcon()}
          <h3 className="ml-3 text-lg font-medium">{getStatusText()}</h3>
        </div>
        <div className="text-sm">
          Confidence: {Math.round(result.confidence * 100)}%
        </div>
      </div>
      
      <div className="p-6">
        <h4 className="text-md font-medium text-gray-900 mb-2">Doctor's Recommendation</h4>
        <p className="text-gray-700 mb-4">{result.recommendation}</p>
        
        <div className="flex justify-between items-center text-sm text-gray-500">
          <span>ID: {result.id.slice(0, 8)}</span>
          <span>Analyzed on {new Date(result.date).toLocaleDateString()}</span>
        </div>
      </div>
    </div>
  );
};

export default AnalysisResult;