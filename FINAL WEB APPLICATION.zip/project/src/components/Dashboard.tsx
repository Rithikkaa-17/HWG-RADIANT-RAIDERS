import React from 'react';
import { UploadedImage } from '../types';
import { CheckCircle, XCircle, AlertTriangle, Droplets, BarChart } from 'lucide-react';

interface DashboardStatsProps {
  images: UploadedImage[];
}

const Dashboard: React.FC<DashboardStatsProps> = ({ images }) => {
  const stats = {
    accepted: images.filter(img => img.result?.classification === 'accepted').length,
    rejected: images.filter(img => img.result?.classification === 'rejected').length,
    infected: images.filter(img => img.result?.classification === 'infected').length,
    disinfected: images.filter(img => img.result?.classification === 'disinfected').length,
    total: images.length
  };

  const getPercentage = (value: number) => {
    if (stats.total === 0) return 0;
    return Math.round((value / stats.total) * 100);
  };

  return (
    <div className="bg-white rounded-lg shadow-sm overflow-hidden">
      <div className="px-4 py-5 sm:p-6">
        <h3 className="text-lg font-medium text-gray-900 flex items-center">
          <BarChart className="h-5 w-5 mr-2 text-teal-600" />
          Analysis Summary
        </h3>
        
        <div className="mt-5 grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4">
          <div className="bg-green-50 rounded-lg overflow-hidden shadow-sm">
            <div className="px-4 py-5 sm:p-6">
              <div className="flex items-center">
                <div className="flex-shrink-0">
                  <CheckCircle className="h-8 w-8 text-green-500" />
                </div>
                <div className="ml-3">
                  <h4 className="text-sm font-medium text-green-800">Accepted</h4>
                  <div className="flex items-baseline">
                    <p className="text-2xl font-semibold text-green-900">{stats.accepted}</p>
                    <p className="ml-2 text-sm text-green-700">{getPercentage(stats.accepted)}%</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          <div className="bg-red-50 rounded-lg overflow-hidden shadow-sm">
            <div className="px-4 py-5 sm:p-6">
              <div className="flex items-center">
                <div className="flex-shrink-0">
                  <XCircle className="h-8 w-8 text-red-500" />
                </div>
                <div className="ml-3">
                  <h4 className="text-sm font-medium text-red-800">Rejected</h4>
                  <div className="flex items-baseline">
                    <p className="text-2xl font-semibold text-red-900">{stats.rejected}</p>
                    <p className="ml-2 text-sm text-red-700">{getPercentage(stats.rejected)}%</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          <div className="bg-amber-50 rounded-lg overflow-hidden shadow-sm">
            <div className="px-4 py-5 sm:p-6">
              <div className="flex items-center">
                <div className="flex-shrink-0">
                  <AlertTriangle className="h-8 w-8 text-amber-500" />
                </div>
                <div className="ml-3">
                  <h4 className="text-sm font-medium text-amber-800">Infected</h4>
                  <div className="flex items-baseline">
                    <p className="text-2xl font-semibold text-amber-900">{stats.infected}</p>
                    <p className="ml-2 text-sm text-amber-700">{getPercentage(stats.infected)}%</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          <div className="bg-blue-50 rounded-lg overflow-hidden shadow-sm">
            <div className="px-4 py-5 sm:p-6">
              <div className="flex items-center">
                <div className="flex-shrink-0">
                  <Droplets className="h-8 w-8 text-blue-500" />
                </div>
                <div className="ml-3">
                  <h4 className="text-sm font-medium text-blue-800">Disinfected</h4>
                  <div className="flex items-baseline">
                    <p className="text-2xl font-semibold text-blue-900">{stats.disinfected}</p>
                    <p className="ml-2 text-sm text-blue-700">{getPercentage(stats.disinfected)}%</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        
        <div className="mt-6">
          <div className="relative pt-1">
            <div className="flex mb-2 items-center justify-between">
              <div>
                <span className="text-xs font-semibold inline-block text-gray-800">
                  Analysis Distribution
                </span>
              </div>
              <div className="text-right">
                <span className="text-xs font-semibold inline-block text-teal-800">
                  {stats.total} Total Images
                </span>
              </div>
            </div>
            <div className="h-2 flex rounded overflow-hidden">
              <div 
                style={{ width: `${getPercentage(stats.accepted)}%` }} 
                className="bg-green-500 transition-all duration-500"
              ></div>
              <div 
                style={{ width: `${getPercentage(stats.rejected)}%` }} 
                className="bg-red-500 transition-all duration-500"
              ></div>
              <div 
                style={{ width: `${getPercentage(stats.infected)}%` }} 
                className="bg-amber-500 transition-all duration-500"
              ></div>
              <div 
                style={{ width: `${getPercentage(stats.disinfected)}%` }} 
                className="bg-blue-500 transition-all duration-500"
              ></div>
            </div>
            <div className="flex text-xs justify-between mt-1 text-gray-600">
              <span>Accepted</span>
              <span>Rejected</span>
              <span>Infected</span>
              <span>Disinfected</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;