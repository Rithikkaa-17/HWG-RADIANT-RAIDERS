import React from 'react';
import { Image, CheckCircle, XCircle, AlertTriangle, Droplets } from 'lucide-react';
import { UploadedImage } from '../types';

interface RecentImagesProps {
  images: UploadedImage[];
  onSelect: (image: UploadedImage) => void;
}

const RecentImages: React.FC<RecentImagesProps> = ({ images, onSelect }) => {
  const getStatusIcon = (image: UploadedImage) => {
    if (!image.result) return null;
    
    switch (image.result.classification) {
      case 'accepted':
        return <CheckCircle className="h-5 w-5 text-green-500" />;
      case 'rejected':
        return <XCircle className="h-5 w-5 text-red-500" />;
      case 'infected':
        return <AlertTriangle className="h-5 w-5 text-amber-500" />;
      case 'disinfected':
        return <Droplets className="h-5 w-5 text-blue-500" />;
      default:
        return null;
    }
  };

  if (images.length === 0) {
    return (
      <div className="bg-white rounded-lg shadow-sm p-6 text-center">
        <Image className="h-12 w-12 mx-auto text-gray-300" />
        <h3 className="mt-2 text-sm font-medium text-gray-900">No images yet</h3>
        <p className="mt-1 text-sm text-gray-500">
          Upload your first X-ray to get started
        </p>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-lg shadow-sm overflow-hidden">
      <div className="bg-gray-50 px-4 py-3 border-b border-gray-200">
        <h3 className="text-lg font-medium text-gray-900">Recent Images</h3>
      </div>
      <ul className="divide-y divide-gray-200">
        {images.map((image) => (
          <li key={image.id} className="hover:bg-gray-50 transition-colors">
            <button
              onClick={() => onSelect(image)}
              className="w-full px-4 py-3 flex items-center justify-between"
            >
              <div className="flex items-center">
                <div className="h-10 w-10 flex-shrink-0 bg-gray-200 rounded-md overflow-hidden">
                  {image.url ? (
                    <img src={image.url} alt={image.name} className="h-full w-full object-cover" />
                  ) : (
                    <Image className="h-6 w-6 m-2 text-gray-400" />
                  )}
                </div>
                <div className="ml-3">
                  <p className="text-sm font-medium text-gray-900 text-left truncate max-w-[150px]">
                    {image.name}
                  </p>
                  <p className="text-xs text-gray-500">
                    {new Date(image.date).toLocaleDateString()}
                  </p>
                </div>
              </div>
              <div className="flex items-center">
                {getStatusIcon(image)}
                <svg className="ml-2 h-5 w-5 text-gray-400" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                  <path fillRule="evenodd" d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z" clipRule="evenodd" />
                </svg>
              </div>
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default RecentImages;