import React, { useState, useRef, useEffect } from 'react';
import { Send, User, Bot } from 'lucide-react';
import { Message } from '../types';

interface ChatProps {
  initialMessages?: Message[];
}

const Chat: React.FC<ChatProps> = ({ initialMessages = [] }) => {
  const [messages, setMessages] = useState<Message[]>(initialMessages);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Enhanced AI responses with medical knowledge
  const generateResponse = (question: string): Promise<string> => {
    return new Promise((resolve) => {
      setIsTyping(true);
      setTimeout(() => {
        let response = "I apologize, but I don't have enough information about that specific query. Please ask something about implants, infections, recovery, or general medical concerns.";
        
        const q = question.toLowerCase();

        // Comprehensive response mapping
        if (q.includes('implant')) {
          if (q.includes('pain')) {
            response = "Some discomfort after implant surgery is normal. However, if you experience severe or increasing pain, especially accompanied by swelling or fever, contact your doctor immediately. This could indicate complications that need immediate attention.";
          } else if (q.includes('care') || q.includes('maintain')) {
            response = "To maintain your implant: 1) Follow strict oral hygiene 2) Attend all follow-up appointments 3) Avoid smoking 4) Report any unusual symptoms promptly 5) Take prescribed medications as directed 6) Follow dietary restrictions if any 7) Keep the implant area clean as instructed by your doctor.";
          } else if (q.includes('life') || q.includes('last')) {
            response = "With proper care and maintenance, smart implants can last many years. The exact lifespan depends on factors like: location of the implant, your overall health, maintenance routine, and regular check-ups. Your doctor can provide a more specific estimate based on your case.";
          } else {
            response = "Smart Implants are advanced medical devices designed with biocompatible materials and nano-sensors for real-time health monitoring. They can detect early signs of complications and help optimize healing. Regular monitoring through our system helps ensure optimal implant performance.";
          }
        } else if (q.includes('infection')) {
          if (q.includes('prevent')) {
            response = "To prevent implant infections: 1) Follow all post-operative care instructions 2) Take antibiotics as prescribed 3) Keep the area clean 4) Avoid touching the implant area with unwashed hands 5) Report any early signs of infection immediately 6) Maintain good overall hygiene 7) Attend all follow-up appointments.";
          } else if (q.includes('treat') || q.includes('cure')) {
            response = "Implant infections are treated based on severity. Treatment may include: 1) Targeted antibiotics 2) Local wound care 3) Debridement if necessary 4) Possible implant removal in severe cases. Always follow your doctor's specific treatment plan.";
          } else {
            response = "Common signs of implant infection include: redness, swelling, increased pain, warmth around the implant, fever, discharge, or unusual odor. If you notice any of these symptoms, contact your healthcare provider immediately. Early detection and treatment are crucial.";
          }
        } else if (q.includes('reject')) {
          response = "Implant rejection occurs when your body's immune system identifies the implant as foreign. Signs include inflammation, pain, reduced functionality, redness, and swelling. Treatment options include immunosuppressants or, in severe cases, implant removal. Early detection through our monitoring system helps prevent rejection.";
        } else if (q.includes('recovery') || q.includes('healing')) {
          if (q.includes('time') || q.includes('long')) {
            response = "Recovery time varies by implant type and individual factors. Generally, initial healing takes 2-6 weeks, while complete integration may take 3-6 months. Factors affecting healing include: overall health, age, implant location, and following post-operative care instructions.";
          } else if (q.includes('exercise') || q.includes('activity')) {
            response = "During recovery, gradually resume activities as directed by your doctor. Initially, avoid strenuous activities and follow specific movement restrictions. Listen to your body and don't rush the healing process. Your doctor will provide a personalized timeline for returning to normal activities.";
          } else {
            response = "For optimal recovery: 1) Follow all post-operative instructions 2) Take prescribed medications 3) Keep the area clean 4) Attend follow-up appointments 5) Report any concerns promptly 6) Get adequate rest 7) Maintain a healthy diet 8) Stay hydrated 9) Avoid smoking and alcohol.";
          }
        } else if (q.includes('complication') || q.includes('problem')) {
          response = "While complications are rare with proper care, watch for: severe pain, fever, excessive swelling, discharge, implant loosening, or reduced function. Our monitoring system helps detect issues early. Contact your healthcare provider immediately if you notice any concerning symptoms.";
        } else if (q.includes('cost') || q.includes('price') || q.includes('insurance')) {
          response = "Implant costs vary based on type, location, and necessary procedures. Many insurance plans provide coverage for medically necessary implants. Contact your insurance provider for specific coverage details. Our office can help with insurance verification and payment plans.";
        }
        
        setIsTyping(false);
        resolve(response);
      }, 1500);
    });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim()) return;
    
    const userMessage: Message = {
      id: Date.now().toString(),
      content: input,
      sender: 'user',
      timestamp: new Date().toISOString()
    };
    
    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsTyping(true);
    
    try {
      const responseText = await generateResponse(input);
      
      const aiMessage: Message = {
        id: (Date.now() + 1).toString(),
        content: responseText,
        sender: 'system',
        timestamp: new Date().toISOString()
      };
      
      setMessages(prev => [...prev, aiMessage]);
    } catch (error) {
      console.error('Error getting response:', error);
    } finally {
      setIsTyping(false);
    }
  };

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  return (
    <div className="flex flex-col h-[500px] bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
      <div className="bg-teal-600 text-white px-4 py-3">
        <h3 className="text-lg font-medium">Medical Assistant</h3>
        <p className="text-xs text-teal-100">Ask questions about your implant or treatment</p>
      </div>
      
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.length === 0 ? (
          <div className="text-center text-gray-500 my-8">
            <Bot className="h-12 w-12 mx-auto text-gray-300 mb-2" />
            <p>Ask me anything about your implant or treatment plan!</p>
          </div>
        ) : (
          messages.map((message) => (
            <div 
              key={message.id}
              className={`flex ${message.sender === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              <div 
                className={`max-w-[80%] rounded-lg px-4 py-2 ${
                  message.sender === 'user' 
                    ? 'bg-teal-600 text-white rounded-br-none' 
                    : 'bg-gray-100 text-gray-800 rounded-bl-none'
                }`}
              >
                <div className="flex items-center gap-2 mb-1">
                  {message.sender === 'user' ? (
                    <User className="h-4 w-4" />
                  ) : (
                    <Bot className="h-4 w-4" />
                  )}
                  <span className="text-xs">
                    {message.sender === 'user' ? 'You' : 'Medical Assistant'}
                  </span>
                </div>
                <p>{message.content}</p>
                <p className="text-xs opacity-70 text-right mt-1">
                  {new Date(message.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </p>
              </div>
            </div>
          ))
        )}
        
        {isTyping && (
          <div className="flex justify-start">
            <div className="bg-gray-100 text-gray-800 rounded-lg rounded-bl-none px-4 py-2">
              <div className="flex space-x-1">
                <div className="h-2 w-2 bg-gray-500 rounded-full animate-bounce"></div>
                <div className="h-2 w-2 bg-gray-500 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                <div className="h-2 w-2 bg-gray-500 rounded-full animate-bounce" style={{ animationDelay: '0.4s' }}></div>
              </div>
            </div>
          </div>
        )}
        
        <div ref={messagesEndRef} />
      </div>
      
      <form onSubmit={handleSubmit} className="border-t border-gray-200 p-4 flex">
        <input 
          type="text" 
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Ask about your implant..."
          className="flex-1 border border-gray-300 rounded-l-md py-2 px-3 focus:ring-2 focus:ring-teal-500 focus:border-transparent outline-none"
        />
        <button 
          type="submit"
          disabled={!input.trim()}
          className={`bg-teal-600 text-white px-4 rounded-r-md flex items-center ${
            !input.trim() ? 'opacity-50 cursor-not-allowed' : 'hover:bg-teal-700'
          }`}
        >
          <Send className="h-4 w-4" />
        </button>
      </form>
    </div>
  );
};

export default Chat;